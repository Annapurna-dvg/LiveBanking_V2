package com.LiveBanking.pageObjects;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;

public class AddNewCustomerPage {
	
	WebDriver driver;
	public AddNewCustomerPage(WebDriver driver)
	{
		this.driver=driver;
		PageFactory.initElements(driver, this);
	}
	@FindBy(how=How.NAME,using="name")
	WebElement CustName;
	
	@FindBy(how=How.XPATH,using="//input[@name='rad1'][2]")
	WebElement gen;
	
	@FindBy(how=How.ID,using="dob")
	WebElement dob;
	
	@FindBy(how=How.XPATH,using="//textarea[@name='addr']")
	WebElement addr;
	
	@FindBy(how=How.NAME,using="city")
	WebElement city;
	
	@FindBy(how=How.NAME,using="state")
	WebElement state;
	
	@FindBy(how=How.NAME,using="pinno") 
	WebElement pin;
	
	@FindBy(how=How.NAME,using="telephoneno")
	WebElement telephoneNum;
	
	@FindBy(how=How.NAME,using="emailid")
	WebElement email;
	
	@FindBy(how=How.NAME,using="sub")
	WebElement sub;
	
	@FindBy(how=How.XPATH,using="//html/body/div[3]/div/ul/li[2]/a")
	WebElement newCustomer;
	 
	public void addNewCust()
	{
		 newCustomer.click();
	}
	public void custName(String cname)
	{
		CustName.sendKeys(cname);
	}
	public void gender()
	{
		gen.click();
	}
	public void dob(String dd,String mm,String yyyy)
	{
		dob.sendKeys(dd);
		dob.sendKeys(mm);
		dob.sendKeys(yyyy);
	} 
	public void address(String caddress)
	{
		addr.sendKeys(caddress);
	}
	public void city(String ccity)
	{
		city.sendKeys(ccity);
	}
	public void state(String cstate)
	{
		state.sendKeys(cstate);
	}
	public void pin(String cpin)
	{
		pin.sendKeys(String.valueOf(cpin));
	}
	public void teleNum(String ctelephone)
	{
		telephoneNum.sendKeys(ctelephone);
	}
	public void emailId(String cemail)
	{
		email.sendKeys(cemail);
	}
	public void submit()
	{
		sub.click();
	}
}

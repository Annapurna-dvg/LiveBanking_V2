package com.LiveBanking.pageObjects;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;

public class LandingPage {
	
	WebDriver driver;
	
	 public LandingPage(WebDriver driver)
	{
		this.driver=driver;
		PageFactory.initElements(driver, this);
	}
	 @FindBy(how=How.XPATH,using="//html/body/div[3]/div/ul/li[2]/a")
	 WebElement newCustomer;
	 
	 public void addNewCust()
	 {
		 newCustomer.click();
	 }

}

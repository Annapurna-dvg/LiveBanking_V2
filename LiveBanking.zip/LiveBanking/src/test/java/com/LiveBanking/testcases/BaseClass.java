package com.LiveBanking.testcases;
import java.io.File;
import java.util.concurrent.TimeUnit;

import org.apache.commons.io.FileUtils;
import org.apache.commons.lang3.RandomStringUtils;
import org.apache.log4j.LogManager;
import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Parameters;

import com.LiveBanking.utilities.ReadConfig;

import net.bytebuddy.utility.RandomString;
public class BaseClass {
	
	ReadConfig readConfig=new ReadConfig();
	public WebDriver driver;
	public String baseURL=readConfig.getBaseURL();
	public String uname=readConfig.getUsername();
	public String pwd=readConfig.getPassword();
	public static Logger log= LogManager.getLogger(BaseClass.class.getName());
	
	@Parameters("browser")
	@BeforeClass
	public void setUp(String br)
	{
		if(br.equalsIgnoreCase("chrome"))
		{
			System.setProperty("webdriver.chrome.driver",readConfig.getChromeDriver());
			driver = new ChromeDriver();
		}
		else
		{
			System.setProperty("webdriver.gecko.driver",readConfig.getFirefoxDriver());
			driver = new FirefoxDriver();
		}
		//log=Logger.getLogger("LiveBanking");
		//PropertyConfigurator.configure("log4j.properties");
		driver.manage().window().maximize();
		driver.get(baseURL);
		driver.manage().timeouts().implicitlyWait(10,TimeUnit.SECONDS);
	}
	
	@AfterClass
	public void tearDown()
	{
		driver.close();
	}
	
	public void screenCapture(WebDriver driver,String tname)
	{
		File src=((TakesScreenshot)driver).getScreenshotAs(OutputType.FILE);
		File dest=new File(System.getProperty("user.dir")+"/Screenshots/"+tname+".png");
		try{
			FileUtils.copyFile(src, dest);
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
		System.out.println("Screenshot taken");
	}
	public String generateRandom()
	{
		String email=RandomStringUtils.randomAlphabetic(5);
		return email;
	}
	public String generateRandomInt()
	{
		String ranInt=RandomStringUtils.randomNumeric(4);
		return ranInt;
	}
}

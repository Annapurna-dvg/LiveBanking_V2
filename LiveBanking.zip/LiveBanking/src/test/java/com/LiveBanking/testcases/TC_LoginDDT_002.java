package com.LiveBanking.testcases;

import java.io.IOException;

import org.openqa.selenium.NoAlertPresentException;
import org.testng.Assert;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import com.LiveBanking.pageObjects.LoginPage;
import com.LiveBanking.utilities.XLUtils;

public class TC_LoginDDT_002 extends BaseClass
{
	
	@Test(dataProvider="LoginTest")
	public void LoginDDT(String uid,String pwd) throws InterruptedException
	{
		LoginPage lp=new LoginPage(driver);
		lp.setUserName(uid);
		log.info("Username entered");
		lp.setPassword(pwd);
		log.info("Password entered");
		lp.clickSubmit();
		log.info("submitted");
		Thread.sleep(3000);
		if(isAlertPresent()==true)
		{
			screenCapture(driver,"LoginDDT");
			driver.switchTo().alert().accept();
			driver.switchTo().defaultContent();
			Thread.sleep(3000);
			Assert.assertTrue(false);
			log.warn("Invalid Credentials");
		}
		else
		{
			Assert.assertTrue(true);
			log.info("Logged-in Successfully");
			lp.logOut();
			Thread.sleep(3000);
			driver.switchTo().alert().accept();
			driver.switchTo().defaultContent();
			log.info("Logged-out Successfully");
		}
	}
	
	public boolean isAlertPresent()
	{
		try
		{
			driver.switchTo().alert();
			return true;
		}
		catch(NoAlertPresentException e)
		{
			return false;
		}
	}
	@DataProvider(name="LoginTest")
	public String[][] getData() throws IOException
	{
		String Excl=System.getProperty("user.dir")+"/src/test/java/com/LiveBanking/testdata/Excel DATA Driven.xlsx";
		int rowCo=XLUtils.getRowCount(Excl, "Sheet2");
		int colCo=XLUtils.getCellCount(Excl, "Sheet2", 1);
		String LoginData[][]=new String[rowCo][colCo];
		for(int i=1;i<=rowCo;i++)
		{
			for(int j=0;j<colCo;j++)
			{
				  LoginData[i-1][j]=XLUtils.getCellData(Excl, "Sheet2", i, j);
			}
		}
		return LoginData;
	}
}

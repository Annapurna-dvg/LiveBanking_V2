package com.LiveBanking.testcases;

import org.testng.annotations.Test;

import com.LiveBanking.pageObjects.AddNewCustomerPage;
import com.LiveBanking.pageObjects.LoginPage;


public class TC_AddCustomer_003 extends BaseClass 
{
	@Test
	public void addNewCustomer() throws InterruptedException
	{
		LoginPage lp=new LoginPage(driver);
		lp.setUserName(uname);
		lp.setPassword(pwd);
		lp.clickSubmit();
		Thread.sleep(3000);
		log.info("Successfully logged in");
		
		AddNewCustomerPage add = new AddNewCustomerPage(driver);
		add.addNewCust();
		
		add.custName("Avvi");
		add.gender();
		add.dob("19","05","1995");
		Thread.sleep(3000);
		add.address("India");
		add.city("Davanagere");
		add.state("Karnataka");
		add.pin("577002");
		add.teleNum("08192232654");
		add.emailId(generateRandom()+"@gmail.com");
		add.submit();
		Thread.sleep(3000);
		log.info("Submitted");
	}
	
	
}

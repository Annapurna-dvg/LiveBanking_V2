package com.LiveBanking.testcases;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.WebDriver;
import org.testng.Assert;
import org.testng.annotations.Test;

import com.LiveBanking.pageObjects.LoginPage;

public class TC_LoginTest_001 extends BaseClass
{    
	@Test
	public void login()
	{
		//driver.get(baseURL);
		log.info("Accessed URL");
		driver.manage().timeouts().implicitlyWait(5,TimeUnit.SECONDS);
		LoginPage lp = new LoginPage(driver);
		lp.setUserName(uname);
		log.info("Entered username");
		lp.setPassword(pwd);
		log.info("Entered Password");
		lp.clickSubmit();
		log.info("submitted");
		System.out.println(driver.getTitle());
		String title=driver.getTitle();
		if(driver.getTitle().equalsIgnoreCase(title))
		{
			System.out.println(driver.getTitle());
			Assert.assertTrue(true);
			log.info("Title validation passed");
		}
		else
		{
			screenCapture(driver,"login");
			System.out.println(driver.getTitle());
			log.info("Title validation failed");
			Assert.assertFalse(true);
		}
		
	}
	
	
	
	
}


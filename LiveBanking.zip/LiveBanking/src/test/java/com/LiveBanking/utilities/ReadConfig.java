package com.LiveBanking.utilities;
import java.io.FileInputStream;
import java.util.Properties;

public class ReadConfig {
	
	Properties prop;
	public ReadConfig()  
	{
		try 
		{
			FileInputStream fis = new FileInputStream("./Configuration\\config.properties");
			prop = new Properties();
			prop.load(fis);
		} catch (Exception e) 
		{
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	public String getBaseURL()
	{
		return prop.getProperty("baseURL");
	}
	public String getUsername()
	{
		return prop.getProperty("uname");
	}
	public String getPassword()
	{
		return prop.getProperty("pwd");
	}
	public String getChromeDriver()
	{
		return prop.getProperty("chrome");
	}
	public String getFirefoxDriver()
	{
		return prop.getProperty("firefox");
	}

}

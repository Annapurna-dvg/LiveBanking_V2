package com.LiveBanking.utilities;

import java.io.File;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Date;

import org.apache.commons.io.FileUtils;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.testng.ITestContext;
import org.testng.ITestListener;
import org.testng.ITestResult;

import com.LiveBanking.testcases.BaseClass;
import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.Status;
import com.aventstack.extentreports.markuputils.ExtentColor;
import com.aventstack.extentreports.markuputils.MarkupHelper;
import com.aventstack.extentreports.reporter.ExtentSparkReporter;
import com.aventstack.extentreports.reporter.configuration.Theme;


public class Reporting extends BaseClass implements ITestListener
{
	ExtentSparkReporter reporter;
	ExtentReports extent;
	ExtentTest test;
	
	public void onStart(ITestContext context) 
	{
		// TODO Auto-generated method stub
		String timeStamp=new SimpleDateFormat("yyyy.mm.dd.hh.mm.ss").format(new Date());
		String repName="Trial-Report-"+timeStamp+".html";
		reporter=new ExtentSparkReporter(System.getProperty(" user.dir")+"/test-output/"+repName);   
		try 
		{
		  reporter.loadXMLConfig(System.getProperty("user.dir")+"/extent-config.xml");
		} 
		catch (IOException e) 
		{ // TODO Auto-generated catch block
		  e.printStackTrace(); 
		}
		 
		reporter.config().setDocumentTitle("Test-Extent Reports");
		reporter.config().setReportName("Login Test Reports");
		reporter.config().setTheme(Theme.DARK);
		extent = new ExtentReports();
		extent.attachReporter(reporter);
		extent.setSystemInfo("Hostname","localhost");
		extent.setSystemInfo("Environment","QA");
		extent.setSystemInfo("User","Avvi");
	}

	public void onTestStart(ITestResult result)
	{
		// TODO Auto-generated method stub
	}
	public void onTestSuccess(ITestResult result) {
		// TODO Auto-generated method stub
		test=extent.createTest(result.getName());
		test.log(Status.PASS,MarkupHelper.createLabel(result.getName(), ExtentColor.GREEN));
	}

	public void onTestFailure(ITestResult result) {
		// TODO Auto-generated method stub
		//String TestMethodName=result.getMethod().getMethodName();
		test=extent.createTest(result.getName());
		test.log(Status.FAIL,MarkupHelper.createLabel(result.getName(), ExtentColor.RED));	
		
		//test.get().addScreenCaptureFromPath(getTakesScreenshot(TestMethodName,driver),TestMethodName);
		
		String path=System.getProperty("user.dir")+"/Screenshots/"+result.getMethod().getMethodName()+".png";
		File dest=new File(path);
		try {
			
			if(dest.exists())
			{
				test.addScreenCaptureFromPath(path);
			}
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	public void onTestSkipped(ITestResult result) 
	{
		// TODO Auto-generated method stub
		test.log(Status.SKIP,MarkupHelper.createLabel(result.getName(),ExtentColor.ORANGE));
	}
	public void onFinish(ITestContext context) {
		// TODO Auto-generated method stub
		extent.flush();
		
	}
	

}
